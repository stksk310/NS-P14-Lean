# NS-P14-Lean

Lean formalization project for NS-P14.

## Mathematical source

- [単一証明の作業稿](proof/NS_P14_SINGLE_PROOF_JA.md)
- [検証境界と残る依存](proof/AUDIT_JA.md)
- [厳密算術の検証記録](proof/verification.json)

The main argument is consolidated around one Apéry tower and one cut. The
ordinary-target argument now reaches embedding dimension `e >= 13`, using
200 exact rational coefficient checks and an analytic tail. Small embedding
dimension and narrow targets retain explicit inherited boundary theorems.

This is an assembly with named mathematical dependencies, not an independently
verified complete proof or a Lean formalization. No Lean toolchain or mathlib
dependency has been selected yet.

```sh
python -B proof/checks/verify_scalar.py
python -B proof/checks/recheck_rows.py
```
